x=read.table('output.score',header=F)
cor(x[,2],x[,3])^2
