I file contenuti in questa directory permettono di generare
(in ambiente Linux/Unix/WSL) la versione italiana
del libro di Arnold GAWK: Programmare efficacemente in AWK,
SE (e solo se) il software necessario è disponibile nel
computer in cui si scarica la distribuzione di gawk.

È inoltre possibile generare la versione PDF del Manuale
utente della funzionalità di Memoria Persistente (pm-gawk),
disponibile a partire dalle versione 5.2 di Gawk.

Se la sola cosa che interessa è avere una copia del
libro Gawk e/o del manuale pm-gawk in formato PDF,
queste possono semplicemente essere scaricate dal sito:

https://sites.google.com/view/gawkdoc-it/home-page

Per generare il libro localmente, è disponibile uno
shell script:

compila_gawk.sh

Un secondo script:

genera_formati.sh

genera il libro Gawk in vari formati, fra cui i formati
testo, html e info.

Per generare il Manuale Utente per la Memoria Persistente
in gawk, è disponibile lo script:

compila_pma.sh

Per eventuali problemi con la traduzione italiana del
libro Gawk e/o del Manuale utente pm-gawk, fare riferimento
agli indirizzi email dei traduttori, inseriti all'inizio
della versione PDF del libro Gawk.
